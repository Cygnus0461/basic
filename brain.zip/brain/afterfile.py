import numpy as np
import glob
import pandas as pd

#フォルダー内のデータ取得
file1 = glob.glob("after/neutral/*.csv")
file2 = glob.glob("after/right/*.csv")
file3 = glob.glob("after/left/*.csv")

data1 = file1
#すべてのcsvファイルを読み込みディレクトリに入れる
dfs = {}
for file in files:
    dfs[os.path.basename(file)] = pd.read_csv(file, header = None)

